const express = require('express');
const router = express.Router();
const db = require('../db'); // Adjust path to your MySQL connection
const verifyToken = require('../middleware/auth'); // JWT middleware

router.get('/dashboard', verifyToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied' });
    }

    const [users] = await db.query('SELECT id, username, role FROM users');
    const [stores] = await db.query(`
      SELECT stores.id, stores.name, users.username AS ownerName
      FROM stores
      JOIN users ON stores.owner_id = users.id
    `);
    const [ratingStats] = await db.query('SELECT COUNT(*) AS totalRatings, AVG(rating) AS avgRating FROM ratings');
    const [storeCount] = await db.query('SELECT COUNT(*) AS totalStores FROM stores');
    const [userCount] = await db.query('SELECT COUNT(*) AS totalUsers FROM users');

    res.json({
      users,
      stores,
      stats: {
        totalUsers: userCount[0].totalUsers,
        totalStores: storeCount[0].totalStores,
        avgRating: ratingStats[0].avgRating || 0
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;