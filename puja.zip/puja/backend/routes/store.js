const express = require('express');
const router = express.Router();
const db = require('../db');
const verifyToken = require('../middleware/auth');

// Get all stores
router.get('/stores', async (req, res) => {
  try {
    const [stores] = await db.query(`
      SELECT s.id, s.name, AVG(r.rating) AS avgRating
      FROM stores s
      LEFT JOIN ratings r ON s.id = r.store_id
      GROUP BY s.id
    `);
    res.json(stores);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to fetch stores' });
  }
});

// Submit a rating
router.post('/rate', verifyToken, async (req, res) => {
  const { storeId, rating, comment } = req.body;
  try {
    await db.query('INSERT INTO ratings (store_id, user_id, rating, comment) VALUES (?, ?, ?, ?)', [
      storeId,
      req.user.id,
      rating,
      comment
    ]);
    res.status(201).json({ message: 'Rating submitted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to submit rating' });
  }
});

module.exports = router;