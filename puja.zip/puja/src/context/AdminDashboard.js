// src/pages/AdminDashboard.js
import { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { toast } from 'react-toastify';

const AdminDashboard = () => {
  const { user } = useContext(AuthContext);
  const [users, setUsers] = useState([]);
  const [stores, setStores] = useState([]);
  const [stats, setStats] = useState({ totalUsers: 0, totalStores: 0, avgRating: 0 });

  useEffect(() => {
    if (!user) return;

    axios.get('http://localhost:5000/api/admin/dashboard', {
      headers: { Authorization: `Bearer ${user.token}` }
    })
      .then(res => {
        setUsers(res.data.users);
        setStores(res.data.stores);
        setStats(res.data.stats);
      })
      .catch(() => toast.error('Failed to load admin data'));
  }, [user]);

  return (
    <div>
      <h2>Admin Dashboard</h2>

      <div>
        <p><strong>Total Users:</strong> {stats.totalUsers}</p>
        <p><strong>Total Stores:</strong> {stats.totalStores}</p>
        <p><strong>Average Rating:</strong> {stats.avgRating || 'N/A'}</p>
      </div>

      <h3>Users</h3>
      <ul>
        {users.map(u => (
          <li key={u.id}>
            {u.username} — Role: {u.role}
          </li>
        ))}
      </ul>

      <h3>Stores</h3>
      <ul>
        {stores.map(s => (
          <li key={s.id}>
            {s.name} — Owner: {s.ownerName}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminDashboard;