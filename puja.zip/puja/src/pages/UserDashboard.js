// src/pages/UserDashboard.js
import { useEffect, useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';

const UserDashboard = () => {
  const [stores, setStores] = useState([]);
  const [selectedStore, setSelectedStore] = useState(null);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');

  useEffect(() => {
    axios.get('http://localhost:5000/api/stores')
      .then(res => setStores(res.data))
      .catch(() => toast.error('Failed to load stores'));
  }, []);

  const submitRating = async () => {
    try {
      await axios.post(`http://localhost:5000/api/rate`, {
        storeId: selectedStore,
        rating,
        comment,
      });
      toast.success('Rating submitted!');
      setSelectedStore(null);
      setRating(0);
      setComment('');
    } catch {
      toast.error('Failed to submit rating');
    }
  };

  return (
    <div>
      <h2>User Dashboard</h2>
      <ul>
        {stores.map(store => (
          <li key={store.id}>
            <strong>{store.name}</strong> - Avg Rating: {store.avgRating || 'N/A'}
            <button onClick={() => setSelectedStore(store.id)}>Rate</button>
          </li>
        ))}
      </ul>

      {selectedStore && (
        <div>
          <h3>Rate Store</h3>
          <input
            type="number"
            min="1"
            max="5"
            value={rating}
            onChange={(e) => setRating(e.target.value)}
            placeholder="Rating (1–5)"
          />
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Comment"
          />
          <button onClick={submitRating}>Submit</button>
        </div>
      )}
    </div>
  );
};

export default UserDashboard;