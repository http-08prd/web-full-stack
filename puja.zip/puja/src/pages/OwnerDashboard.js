// src/pages/OwnerDashboard.js
import { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { toast } from 'react-toastify';

const OwnerDashboard = () => {
  const [ratings, setRatings] = useState([]);
  const [avgRating, setAvgRating] = useState(null);
  const { user } = useContext(AuthContext);

  useEffect(() => {
    if (!user) return;

    axios.get(`http://localhost:5000/api/owner/ratings`, {
      headers: { Authorization: `Bearer ${user.token}` }
    })
      .then(res => {
        setRatings(res.data.ratings);
        setAvgRating(res.data.avgRating);
      })
      .catch(() => toast.error('Failed to load ratings'));
  }, [user]);

  return (
    <div>
      <h2>Store Owner Dashboard</h2>
      <p><strong>Average Rating:</strong> {avgRating || 'N/A'}</p>
      <ul>
        {ratings.map(r => (
          <li key={r.id}>
            <strong>Rating:</strong> {r.rating} <br />
            <strong>Comment:</strong> {r.comment}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default OwnerDashboard;